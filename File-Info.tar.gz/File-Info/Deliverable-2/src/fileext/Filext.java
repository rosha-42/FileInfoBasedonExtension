package fileext;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
public class Filext extends Crawler implements Runnable
{
	
	String ext="";
	//constructor to pass extension 
	public Filext(String string) {
		this.ext=string;	
	}
	 public void run()
	   {
		   try
		   {
			   //	Source URL
			   String html = "http://filext.com/file-extension/"+ext;
			   //Follow Up Code Will Be Used To Extract Information From Source
			   Document doc = Jsoup.connect(html).get();
			   Elements FileInfo=doc.select("ul");
			   String OtherApplication="";
			   for(Element element :FileInfo)
			   {
				   Elements Application =element.select("span[class=application]");
				   for(Element App:Application)
				   {
					   if(OtherApplication.equals(""))
						   OtherApplication=OtherApplication+App.text();
					   else
						   OtherApplication=OtherApplication+" , "+App.text();
				   }
			   }
			   if(!OtherApplication.equals(""))
			   {  
				   Insert("OtherApplications-",OtherApplication);
			    }
		   }
		   catch(Exception e)
		   {
			   Insert("ERROR-","404 no data avialable at File-Extension");
		   }
		}
}