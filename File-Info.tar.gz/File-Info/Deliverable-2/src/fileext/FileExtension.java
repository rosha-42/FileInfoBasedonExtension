package fileext;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
public class FileExtension extends Crawler implements Runnable
{
	
	String ext="";
	//constructor to pass extension 
	public FileExtension(String string) {
		this.ext=string;	
	}
	public void run()
	   {
		   try
		   {
				//Source URL
				String html = "https://www.file-extensions.org/"+ext+"-file-extension";
				//Follow Up Code Will Be Used To Extract Information From Source
		      	Document doc = Jsoup.connect(html).get();
		      	Elements Temp=doc.select(".left");
		      	Element Heading =Temp.select("h2").first();
		      	String FileType=Heading.select("span").text();
		      	Insert("FileType-", FileType.substring(1));
		      	String Description=doc.select("div[itemtype=description]").text();
		      	Insert("Description-",Description );
		    	       
			}
			catch (Exception e)
			   {
			      // Throwing an exception
				Insert("ERROR-","404 no data avialable at FileSuffix");
			   }
	   	}	
}